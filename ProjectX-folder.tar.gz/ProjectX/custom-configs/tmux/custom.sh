#/etc/profile.d/custom.sh
#Custom shell configuration for tmux to provide source IP based tmux exemption
#
#Sept 2024
#https://github.com/jasonwilkins/RHEL8-buildabox
#Initial Public Release
#Place this file in /etc/profile.d/
#
#Original source: https://unix.stackexchange.com/questions/19001/prevent-tmux-from-starting-up-on-ssh
#For more information on SSH variables, see: https://linux.die.net/man/1/ssh
#Made for RHELv8.10
#The purpose of this file is to exempt the IP address below from tmux requirement
#Required for security scanners like Tenable.sc/ACAS
#Should meet the requirements of STIG V-230349
#
case "$SSH_CONNECTION" in
#If an ssh connection is from the below IP, skip TMUX and exit to default shell
   192.168.10.45*)
   ;;
#If an ssh connection is from any other IP, load TMUX
   *)
   if [ "$PS1" ]; then
     parent=$(ps -o ppid= -p $$)
     name=$(ps -o comm= -p $parent)
     case "$name" in (sshd|login) exec tmux ;; esac
   fi
   ;;
#Local Console connections also load TMUX
   '')
   if [ "$PS1" ]; then
     parent=$(ps -o ppid= -p $$)
     name=$(ps -o comm= -p $parent)
     case "$name" in (sshd|login) exec tmux ;; esac
   fi
   ;;
esac
