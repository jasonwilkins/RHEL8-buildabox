#!/bin/bash
#Sets up tmux configuration and ensure tmux always starts
#Sept 2024
#https://github.com/jasonwilkins/RHEL8-buildabox
#Initial Public Release
#
#Set tmux config options
rm -f /etc/tmux.conf
touch /etc/tmux.conf
cat << EOF > /etc/tmux.conf
#https://man.openbsd.org/tmux
set -g lock-after-time 900
set -g lock-command vlock
bind X lock-session
set -g history-limit 12000
set -g status-left-length 25
set -g status-right-length 55
#https://man.openbsd.org/strftime.3
set -g status-right " \"#{=30:pane_title}\" %R %Z %a %d-%b-%y"
EOF
chmod 644 /etc/tmux.conf
#
#--# xccdf_mil.disa.stig_rule_SV-230350r627750_rule RHEL-08-020042
#--# low
#Prevent tmux disabling
sed -i "/tmux/d" /etc/shells
#
#Set tmux exemption for IPs that needs direct bash shell, i.e. no tmux
#Change the IP in custom.sh to something you need a direct bash connection for
#tmux is not friendly to long strings scanners use for fuzzing and can result in non-credentialed scans
#This includes Tenable.sc or DoD ACAS security scanning solution
cp -f /mnt/cdrom/ProjectX/custom-configs/tmux/custom.sh /etc/profile.d && chmod 644 /etc/profile.d/custom.sh
